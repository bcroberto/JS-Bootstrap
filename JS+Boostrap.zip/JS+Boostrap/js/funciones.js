function creaCampos() {
    var objetoDiv1=document.getElementsByTagName('div')[0];
    var campoNombre=document.createElement('input');
    objetoDiv1.appendChild(campoNombre);
    campoNombre.placeholder='Pon tu nombre'
    campoNombre.onblur=sacarAlert;  
}

function sacarAlert() {
    var valorInput=document.getElementsByTagName('input')[0].value;
    if (valorInput.length<=4) {
        var alertRojo=document.getElementById('contenedor_aviso');
        alertRojo.className='alert alert-danger';
        alertRojo.innerHTML='<strong>ERROR!</strong> El campo debe ser de mas de 4 caracteres';
    } 
    else{
        var alertSucces=document.getElementById('contenedor_aviso');
        alertSucces.className='alert alert-success';
        alertSucces.innerHTML='<strong>CORRECTO!</strong> El campo cumple las condiciones';
    }
}